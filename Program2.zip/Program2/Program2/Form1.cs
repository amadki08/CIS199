﻿//W2613
//Due March 8
// Section 1
// Program 2
//Purpose of program to show dates and times of regristration based on last name and credit hours.



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //DECLARE VARIABLES//
            Char ch;
            int hours; //credit hours
            string day; //day of reg
            string seniorDay = "Wednesday, March 28";//senior day
            string juniorDay = "Thursday, March 29";// junior day
            string time; // time of reg
            string time1 = "8:30"; // first time
            string time2 = "10:00"; // second time
            string time3 = "11:00"; // 3rd time 
            string time4 = "2:00"; // 4th time 
            string time5 = "4:00"; // 5th time 
            float Freshman = 29; // freshman hours
            float Soph = 30; // sophomore hours
            float junior = 60; // junior hours
            float senior = 90; // senior hours
            string Soph1 = "Friday, March 30"; // sophmore day 1
            string Soph2 = "Monday, April 2"; // sophmore day 2
            string Fresh1 = "Tuesday, April 3"; // freshman day 1
            string Fresh2 = "Wednesday, April 4"; //Freshman day 2



            //INPUT//
            if (char.TryParse(InitialTB.Text, out ch) && (ch < 'A'))
            {
                if (int.TryParse(HoursTB.Text, out hours) && (hours <= 0)) 
                {
                    // Seniors and Juniors Time//
                    if (hours >= junior)
                    {
                        if (ch <= 'D')
                            time = time1;
                        else
                            if (ch <= 'I')
                            time = time2;
                        else
                            if (ch <= 'O')
                            time = time3;
                        else
                            if (ch <= 'S')
                            time = time4;
                        else
                            time = time5;
                    }
                    // Underclassman Time //
                    else

                    {
                        if (ch <= 'B' || ch == 'M' || ch == 'N' || ch == 'O')
                            time = time1;

                        else
                           if (ch <= 'D' || ch == 'Q' || ch == 'P')
                            time = time2;
                        else
                            if (ch <= 'F' || ch == 'S' || ch == 'R')
                            time = time3;
                        else
                            if (ch <= 'I' || ch == 'T' || ch == 'U' || ch == 'V')
                            time = time4;
                        else
                            time = time5;
                    }

                    // Junior and Senior Days//


                    if (hours >= senior)
                        day = seniorDay;
                    else
                        day = juniorDay;
                    // Underclassmen Days //
                    if (hours <= Soph)
                    {
                        if (ch <= 'L')
                            day = Soph1;
                        else
                            day = Soph2;
                    }
                    else
                      if (hours <= Freshman)
                    {
                        if (ch <= 'L')
                            day = Fresh1;
                        else
                            day = Fresh2;
                    }
                    // Output //
                    OutputLabel.Text = ($"{day} at {time}");
                }      
             else
               MessageBox.Show("Enter a Letter!");
            }
            else
                MessageBox.Show("Enter a Integer for Hours!");

       




        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
