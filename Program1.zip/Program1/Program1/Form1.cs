﻿//W2613
// Program #1
// Due Date : Feb 13 2018
// Section #1
// Calculates and estimates  number and price of paint needed to paint building 



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculatebutton_Click(object sender, EventArgs e)
        {
            // Declare Variables
            Double length; // Length of walls variable
            Double height; // Lenght of height vairable 
            int doors; // number of doors
            int windows; // number of windows
            int coats; // number of coats
            double pergallon; // cost per gallon
            double sqft; //calculates square feet
            const int est= 375; // estimate of 375 square feet covered
            const int doorssub = 20; // subtraction of doors at 20
            const int windowsub = 15; // subtraction of windows at 15
            decimal total; // total sqft *coats/ 375
            int recomTotal; // recommended total 
            double price; // cost of recommended total * gallon

            // input
            length = double.Parse(LengthWallsTB.Text);
            height = double.Parse(HeightWallsTB.Text);
            doors = int.Parse(DoorsTB.Text);
            windows = int.Parse(WindowsTB.Text);
            coats = int.Parse(CoatsTB.Text);
            pergallon = double.Parse(PerGallonTB.Text);



            //calculations
            sqft = length * height;
            sqft = sqft -(windowsub * windows) + (doorssub * doors);
            total = sqft * coats/est;
            recomTotal = (int)Math.Ceiling(total);
            price = recomTotal * pergallon;

            //output

            OutputLabel.Text = ($"You need a minimum of {total:F1} gallons of paint." +
                $"You'll need to buy {recomTotal} gallons, though," +
                $"at a cost of {price:F2}. ");
            
        }

        private void LengthWallsTB_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
