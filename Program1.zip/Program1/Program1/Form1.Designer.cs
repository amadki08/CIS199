﻿namespace Program1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.calculatebutton = new System.Windows.Forms.Button();
            this.CoatsTB = new System.Windows.Forms.TextBox();
            this.WindowsTB = new System.Windows.Forms.TextBox();
            this.DoorsTB = new System.Windows.Forms.TextBox();
            this.HeightWallsTB = new System.Windows.Forms.TextBox();
            this.LengthWallsTB = new System.Windows.Forms.TextBox();
            this.PerGallonTB = new System.Windows.Forms.TextBox();
            this.OutputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Welcome to the Handy-Dandy Paint Estimator ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Enter the total length of walls (in feet): ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Enter the height of the walls (in feet):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(193, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "enter the number of doors (non-neg int):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(206, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Enter the number of windows (non-neg int)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(232, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Enter the number of coats of paint (non-neg int):";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 173);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(189, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Enter the cost per gallon of paint (in $):";
            // 
            // calculatebutton
            // 
            this.calculatebutton.Location = new System.Drawing.Point(16, 199);
            this.calculatebutton.Name = "calculatebutton";
            this.calculatebutton.Size = new System.Drawing.Size(113, 23);
            this.calculatebutton.TabIndex = 7;
            this.calculatebutton.Text = "Calculate Estimate";
            this.calculatebutton.UseVisualStyleBackColor = true;
            this.calculatebutton.Click += new System.EventHandler(this.calculatebutton_Click);
            // 
            // CoatsTB
            // 
            this.CoatsTB.AcceptsTab = true;
            this.CoatsTB.Location = new System.Drawing.Point(269, 147);
            this.CoatsTB.Name = "CoatsTB";
            this.CoatsTB.Size = new System.Drawing.Size(100, 20);
            this.CoatsTB.TabIndex = 5;
            // 
            // WindowsTB
            // 
            this.WindowsTB.AcceptsTab = true;
            this.WindowsTB.Location = new System.Drawing.Point(269, 121);
            this.WindowsTB.Name = "WindowsTB";
            this.WindowsTB.Size = new System.Drawing.Size(100, 20);
            this.WindowsTB.TabIndex = 4;
            // 
            // DoorsTB
            // 
            this.DoorsTB.AcceptsTab = true;
            this.DoorsTB.Location = new System.Drawing.Point(269, 95);
            this.DoorsTB.Name = "DoorsTB";
            this.DoorsTB.Size = new System.Drawing.Size(100, 20);
            this.DoorsTB.TabIndex = 3;
            // 
            // HeightWallsTB
            // 
            this.HeightWallsTB.AcceptsTab = true;
            this.HeightWallsTB.Location = new System.Drawing.Point(269, 69);
            this.HeightWallsTB.Name = "HeightWallsTB";
            this.HeightWallsTB.Size = new System.Drawing.Size(100, 20);
            this.HeightWallsTB.TabIndex = 2;
            // 
            // LengthWallsTB
            // 
            this.LengthWallsTB.AcceptsTab = true;
            this.LengthWallsTB.Location = new System.Drawing.Point(269, 43);
            this.LengthWallsTB.Name = "LengthWallsTB";
            this.LengthWallsTB.Size = new System.Drawing.Size(100, 20);
            this.LengthWallsTB.TabIndex = 1;
            this.LengthWallsTB.TextChanged += new System.EventHandler(this.LengthWallsTB_TextChanged);
            // 
            // PerGallonTB
            // 
            this.PerGallonTB.AcceptsReturn = true;
            this.PerGallonTB.AcceptsTab = true;
            this.PerGallonTB.Location = new System.Drawing.Point(269, 173);
            this.PerGallonTB.Name = "PerGallonTB";
            this.PerGallonTB.Size = new System.Drawing.Size(100, 20);
            this.PerGallonTB.TabIndex = 6;
            // 
            // OutputLabel
            // 
            this.OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutputLabel.Location = new System.Drawing.Point(135, 203);
            this.OutputLabel.Name = "OutputLabel";
            this.OutputLabel.Size = new System.Drawing.Size(234, 94);
            this.OutputLabel.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 302);
            this.Controls.Add(this.OutputLabel);
            this.Controls.Add(this.PerGallonTB);
            this.Controls.Add(this.LengthWallsTB);
            this.Controls.Add(this.HeightWallsTB);
            this.Controls.Add(this.DoorsTB);
            this.Controls.Add(this.WindowsTB);
            this.Controls.Add(this.CoatsTB);
            this.Controls.Add(this.calculatebutton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button calculatebutton;
        private System.Windows.Forms.TextBox CoatsTB;
        private System.Windows.Forms.TextBox WindowsTB;
        private System.Windows.Forms.TextBox DoorsTB;
        private System.Windows.Forms.TextBox HeightWallsTB;
        private System.Windows.Forms.TextBox LengthWallsTB;
        private System.Windows.Forms.TextBox PerGallonTB;
        private System.Windows.Forms.Label OutputLabel;
    }
}

