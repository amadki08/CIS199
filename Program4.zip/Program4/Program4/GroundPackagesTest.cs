﻿//W2613
// Program 4
//Due 4/24/2018
// DIsplays packages in method 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    class GroundPackagesTest
    {
        static void Main(string[] args)
        {
            // Create 5 objects of GroundPackages class
            GroundPackages gp1 = new GroundPackages(40220, 68492, 100, 85, 50, 120);
            GroundPackages gp2 = new GroundPackages(40291, 49021, 60, 60, 30, 140);
            GroundPackages gp3 = new GroundPackages(40219, 56978, 80, 40, 20, 270);
            GroundPackages gp4 = new GroundPackages(40228, 11020, 70, 54, 40, 89);
            GroundPackages gp5 = new GroundPackages(40299, 98765, 99.5, 82.12, 65, 140);

            // Create an array and store these objects in package array
            GroundPackages[] package = { gp1, gp2, gp3, gp4, gp5 };

            // Calls the  function to display packages
            DisplayPackages(package);

            // Changes gp1 and display it
            gp1.OriginZip = 49000;
            gp1.Length = 35.4;
            display(gp1);

            // Changes gp2 and display it
            gp2.Length = 8;
            display(gp2);
        }
        static void DisplayPackages(GroundPackages[] packages)
        {
            //Precondition: Iterate loop using for loop over packages array until loop ends.
            //PostCondition: Print package number & Prints shipping cost
           
            
            for (int i = 0; i < packages.Length; i++)
            {
                Console.WriteLine("Package " + (i + 1) + "\n******");
                Console.WriteLine(packages[i]);
                Console.WriteLine($"{"Shipping Cost"}: ${ packages[i].CalcCost()}");
                Console.WriteLine();
            }
        }

        static void display(GroundPackages packages)
        {
            //Preconditon: Prints package
            //Postcondition: Print shipping cost by calling function
            Console.WriteLine(packages);
            Console.WriteLine($"{"Shipping Cost"}: ${ packages.CalcCost()}");
            Console.WriteLine();
        }
    }
}
