﻿//W2613
//Program 4
//Due Tuesday April 24
// Creates application that collects orgin and destination zip codes and calculates cost

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    class GroundPackages
    {
        // declare variables
        private int originZip; // orgin zip
        private int destinatonZip; // destination zip
        private double length; // length of package
        private double width; // width or package
        private double height; // height of package 
        private double weight; // weight of package
        int defaultMinZip = 10000; // default lowest zip
        int defaultMaxZip = 99999; // default highest zip
        int defaultOrginzip= 40202; // default orgin zip
        int defaultDestzip = 90210; // default destination zip 

        //Precondition: sets paramaters for groundpackages 
        //Postcondition: sets prarmeters in list 
        public GroundPackages(int o, int d, double l, double w, double h, double we)
        {
            OriginZip = o;// orgin zip 
            DestinatonZip = d; // destination zip
            Length = l; // length 
            Height = h; // height 
            Width = w; // width 
            Weight = we; // weight 

        }

        //PreCondition: if value for orgin zip is not valid sets to default 
        //PostCondition: returns valid value or default to orgin zip method 
        public int OriginZip
        {
            get { return originZip; }
            set
            {
                if (value >= defaultMinZip && value <= defaultMaxZip)
                    originZip = value;
                else
                    originZip = defaultOrginzip;
            }
        }
        //PreCondition: if value is not valid for dest. zip>=111111<=99999 sets to default 
        //PostCondtition: returns valid destination zip 
        public int DestinatonZip
        {
            get { return destinatonZip; }
            set
            {
                if (value >= defaultMinZip && value <= defaultMaxZip)
                    destinatonZip = value;
                else
                    destinatonZip = defaultDestzip;
            }
        }
        //PreCondition: if value given is <= 0 sets value to 1.0
        //PostCOndition: returns valid lenght to method using value or 1.0 length
        public double Length
        {
            get { return length; }
            set
            {
                // If value is not valid, set it to 1.0
                if (value > 0)
                    length = value;
                else
                    length = 1.0;
            }
        }
        //PreCondition: if value given is <= to 0 sets value to 1.0
        //PostCondtition: returns valid width to method 
        public double Width
        {
            get { return width; }
            set
            {
                if (value > 0)
                    width = value;
                else
                    width = 1.0;
            }
        }
        //PreCOndtition:sees if value given for height is vaalide >0 if not sets to 10
        //PostCondition: returns height to method using value given or default
        public double Height
        {
            get { return height; }
            set
            {
                if (value > 0)
                    height = value;
                else
                    height = 1.0;
            }
        }
        //PreCondition: sees if value given is valid >0 if not weight = 1.0
        //PostCondition: returns weight usng value or default 
        public double Weight
        {
            get { return weight; }
            set
            {
                if (value > 0)
                    weight = value;
                else
                    weight = 1.0;
            }
        }
        //Precondition:finds first digit or orgin and destination zip both divided by 10000
        //Postcondition: returns difference between first orgin and first digit destination to ZoneDistance method 
        public int ZoneDistance
        {
            get
            {
                int firstOrgin = OriginZip / 10000;
                int firstDest = DestinatonZip / 10000;
                return (firstDest - firstOrgin); 
            }
        }

        public override string ToString()
        {

            //Precondition: Use string interpolation to format strings with NewLine and  will set the string to left with width 20
            //Postcondition: this will overide method on new line for each string 
            
            return $"{"Origin ZipCode"}: {OriginZip}" + Environment.NewLine +
            $"{"Destination ZipCode"}: {DestinatonZip}" + Environment.NewLine +
            $"{"Length"}: {Length}" + Environment.NewLine +
            $"{"Height"}: {Height}" + Environment.NewLine +
            $"{"Width"}: {Width}" + Environment.NewLine +
            $"{"Weight"}: {Weight}";
        }
        //Precondition:Calculates cost by using given formula
        //Postcondition: returns cost to CalcCost method
        public double CalcCost()
        {
            // Calculates the  cost and returns cost
            double cost = .20 * (Length + Width + Height) + .5 * (ZoneDistance + 1) * (Weight);
            return cost;

        }
    }
}
    

